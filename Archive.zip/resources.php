<?php
require_once 'classes/game_controller.php';
$game_controller = new GameController();
 ?>
